# Electricity Bill Management System

1.  ER Diagram

![image](https://user-images.githubusercontent.com/64922494/126759470-a90c39af-11d0-4c68-9db0-178d8a1d9d08.png)

2.  Schema Diagram

![image](https://user-images.githubusercontent.com/64922494/126759647-ba58b8c2-9ec4-4ce9-be25-a595b20ea177.png)


List of entries for the tables:


1. Customer

![image](https://user-images.githubusercontent.com/64922494/125331111-2d87ab00-e365-11eb-8ffa-803e02007a88.png)

2. Admin

![image](https://user-images.githubusercontent.com/64922494/125331238-590a9580-e365-11eb-9103-0b0607ab5a0c.png)

3. Account

![image](https://user-images.githubusercontent.com/64922494/125331286-6aec3880-e365-11eb-8c5d-ba227a6ca5e0.png)

4. Billing

![image](https://user-images.githubusercontent.com/64922494/125331377-88b99d80-e365-11eb-92ad-a9bddb19816a.png)

5. Elec_board

![image](https://user-images.githubusercontent.com/64922494/125331440-9d963100-e365-11eb-8cae-7809d155aabc.png)

6. Tariff

![image](https://user-images.githubusercontent.com/64922494/125331831-20b78700-e366-11eb-9688-5c71e26087fd.png)

7. Invoice

![image](https://user-images.githubusercontent.com/64922494/125331529-bc94c300-e365-11eb-9551-31dd28fbdcdb.png)
